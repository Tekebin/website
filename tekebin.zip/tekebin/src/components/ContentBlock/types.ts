export interface ContentBlockProps {
  icon: string;
  title: string;
  content: string;
  content1: string;
  content2: string;
  section?: any;
  button?: any;
  t?: any;
  id: string;
  type?: string;
}
